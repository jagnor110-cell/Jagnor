Exam Sprint & Spaced Repetition Planner

Interactive single-page HTML5 study scheduler that calculates optimal daily review intervals and topic pacing before test day.
