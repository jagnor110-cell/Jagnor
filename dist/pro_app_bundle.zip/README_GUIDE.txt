Freelance True-Rate & Project Quote Calculator

An interactive single-page HTML5/JS micro-app that computes real billable hourly rates, tax reserves, non-billable time overhead, and instant itemized client quotes.
