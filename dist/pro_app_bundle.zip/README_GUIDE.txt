Exam Sprint: Adaptive Study Block Planner

Interactive single-page HTML5/JS planner that generates a spaced-repetition study schedule from your exam dates, topic weights, and daily focus hours.
