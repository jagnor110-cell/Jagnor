ExamSprint: Spaced Repetition Study Planner

Interactive single-page HTML5 study schedule generator that optimizes daily review blocks by exam date, topic difficulty, and available hours.
