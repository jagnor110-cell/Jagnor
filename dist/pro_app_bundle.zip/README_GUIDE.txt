Spaced Repetition Exam Sprint Planner

A single-page interactive study schedule calculator that maps optimal daily review intervals up to your exam date.
