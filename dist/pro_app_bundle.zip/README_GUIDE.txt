Freelance True-Rate & Quote Calculator

Interactive single-page HTML5 calculator to price fixed-fee projects while factoring in taxes, revisions, and non-billable overhead.
