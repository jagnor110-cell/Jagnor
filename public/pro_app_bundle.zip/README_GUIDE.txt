Smart Focus & Energy Sprint Planner
Interactive study sprint, deep-work & hydration calculator.

Live Web App: https://jagnor110-cell.github.io/Jagnor/
